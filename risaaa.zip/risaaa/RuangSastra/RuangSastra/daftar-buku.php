<!DOCTYPE html>
<html>
<head>
  <title>INPUT DATA NOVEL</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
 <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
body{
  background-image: url(image/walmenu2.jpg);
  background-repeat: no-repeat;
  background-size: cover;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: white;
}
.form-control{
  width: 350px;
}



    </style>
</head>
<body>
      
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <img src="image/ikonnav.png" alt="" width="50" height="50" class="me-2">
          <strong>Ruang SASTRA</strong>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="menu_utama_admin.php">Beranda</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="data-pegawai.php">Data Pegawai</a>
              </li>
               <li class="nav-item">
                <a class="nav-link" href="daftar-buku.php">Daftar Buku</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="daftar-pesanan-admin.php">Daftar Pesanan</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="data-pembayaran.php">Data Pembayaran</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="logout.php">LogOut</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

  <!-- Modal -->
<div class="modal fade" id="adminModal" tabindex="-1" aria-labelledby="adminModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="color: black;">
        <h5 class="modal-title" id="adminModalLabel">Tambah Data Novel</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
       

      <form action="koneksi.php" method="post">
      <div class="modal-body" style="color: black;">

            <div class="form-group">
              <label for="exampleFormControlInput1" class="form-label"><b>Kode_novel</b></label>
              <input type="text" name="Kode_novel" class="form-control"  id="exampleFormControlInput1" placeholder="Masukkan Kode Novel">
            </div>
            <div class="form-group">
              <label for="exampleFormControlInput1" class="form-label"><b>Judul_novel</b></label>
              <input type="text" name="Judul_novel" class="form-control"  id="exampleFormControlInput1" placeholder="Masukkan Judul Novel">
            </div>
            <div class="form-group">
              <label for="exampleFormControlInput1" class="form-label"><b>Genre</b></label>
              <input type="text" name="Genre" class="form-control"  id="exampleFormControlInput1" placeholder="Masukkan Genre Novel">
            </div>
            <div class="form-group">
              <label for="exampleFormControlInput1" class="form-label"><b>Harga</b></label>
              <input type="text" name="Harga" class="form-control"  id="exampleFormControlInput1" placeholder="Masukkan Harga Novel">
            </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" name="addnovel" class="btn btn-primary">Simpan Data</button>
            </div>
          </form>


          </div>
        </div>
      </div>



  <div class="container mt-5">
    <div class="jumbotron" style="color: black;">
      <div class="card" style="color: black;">
        <h2>Daftar Novel</h2>
        
      </div>

      <div class="card">
        <div class="card-body">
          <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#adminModal">Tambah Data</button>
          <button>
           <a href="menu_utama_admin.php" class="btn btn-dark">Kembali</a>
          </button>
        </div>
      </div>
     
      <div class="card">
        <div class="card-body">

          <?php  
              $ambildatanovel = mysqli_connect("localhost","root","");
              $db = mysqli_select_db($ambildatanovel, 'db_ruangsastra');

              $query = "SELECT * FROM tb_buku";
              $query_run = mysqli_query($ambildatanovel, $query);
            ?>


          <table class="table table-dark table-bordered dtable">

            <thead>
              <tr>
                <th scope="col">Kode Novel</th>
                <th scope="col">Judul Novel</th>
                <th scope="col">Genre</th>
                <th scope="col">Harga</th>
                <th scope="col">EDIT</th>
                <th scope="col">HAPUS</th>


              </tr>
            </thead>
             <?php
              if($query_run)
              {
                foreach($query_run as $row)
                {
            ?>
            <tbody>
              <tr>
                <td><?php echo $row['Kode_novel']; ?></td>
                <td><?php echo $row['Judul_novel']; ?></td>
                <td><?php echo $row['Genre']; ?></td>
                <td><?php echo $row['Harga']; ?></td>
                <td>
                  <a href="edit-novel.php?id=<?php echo $row['Kode_novel'];?>" class="btn btn-info"><i class="fa-solid fa-pen"></i>EDIT</a>
                </td>
                <td>
                  <a href="proses-hapus.php?id=<?php echo $row['Kode_novel'];?>" class="btn btn-danger" onclick="javascript: return confirm('Anda Yakin Akan Hapus Data?')"><i class="fa-solid fa-circle-trash"></i>HAPUS</a>
                </td>
                
              </tr>
            </tbody>
             <?php
                }
              }
                else
                {
                  echo "Data Tidak Ditemukan";
                }

          ?>
          </table>
        </div>
      </div>

    </div>
  </div>
  
   




<script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
 <script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
 <script>
 $(document).ready(function() {
  $('.dtabel').dataTable();
 } );
 </script>
 
</body>
</html>

