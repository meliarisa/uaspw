var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

<?php

#DEKLARASI VARIABEL
$hostname="localhost";
$Username="root";
$Password="";
$database="db_ruangsastra";

#Koneksi ke server database
$koneksi=mysqli_connect($hostname,$Username,$Password,$database) or die("koneksi gagal");

#Memilih database
if(mysqli_connect_error()){
	echo "koneksi database mysqli gagal!!! : . mysqli_connect_error()";
}
?>

