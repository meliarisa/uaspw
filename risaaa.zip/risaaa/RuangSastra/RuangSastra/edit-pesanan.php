<!DOCTYPE html>
<html lang="en">
<head>
 <title>FORM EDIT PESANAN</title>
 <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
body{
  background-image: url(image/walmenu2.jpg);
  background-repeat: no-repeat;
  background-size: cover;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: white;
}
.form-control{
  width: 350px;
}



    </style>

 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
 <script src="js/jquery.js"></script>
 <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body background="img/toge.jpg">


	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
      <img src="image/ikonnav.png" alt="" width="50" height="50" class="me-2">
      <strong>Ruang SASTRA</strong>
    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <form class="d-flex ms-auto">
      <input class="form-control me-2" type="search" placeholder="Cari Novel Anda" aria-label="Cari">
      <button class="btn btn-light" type="submit">Cari</button>
    </form>
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="menu_utama_admin.php">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="data-pegawai.php">Data Pegawai</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="daftar-buku.php">Daftar Buku</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="daftar-pesanan-admin.php">Daftar Pesanan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">LogOut</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>



<div class="container mt-5">
    <div class="jumbotron" style="color: black;">
      <div class="card" style="color: black;">
        <h2>Update Data Pegawai</h2>
        
      </div>
  <div class="card">
  	<div class="card-body">

			<?php
			$id = $_GET['id'];
			//koneksi database
			include('koneksi.php');
			//query

			$result = mysqli_query($koneksi, "select*from tb_pesanan WHERE Kode_User='$id'");
			?>

			 <form role="form" action="proses-edit-pesanan.php" method="get">
			<?php
			 while ($row = mysqli_fetch_array($result)){?>

			 <input type="hidden" name="id" value="<?php echo $row ['Kode_User']?>">
			  <div class="form-group">
			  <label>Kode User</label>
			  <input type="text" name="Kode_User" class="form-control" value="<?php echo $row ['Kode_User'];?>">
			 </div>

			 <div class="form-group">
			  <label>Kode Novel</label>
			  <input type="text" name="Kode_novel" class="form-control" value="<?php echo $row ['Kode_novel'];?>">
			 </div>

			 <div class="form-group">
			  <label>Judul Novel</label>
			  <input type="text" name="Judul_novel" class="form-control" value="<?php echo $row ['Judul_novel'];?>">
			 </div>

			 <div class="form-group">
			  <label>Harga</label>
			  <input type="text" name="Harga" class="form-control" value="<?php echo $row ['Harga'];?>">
			 </div>

			 <div class="form-group">
			  <label>Tanggal Pemesanan</label>
			  <input type="text" name="Tanggal_pemesanan" class="form-control" value="<?php echo $row ['Tanggal_pemesanan'];?>">
			 </div>
			 
			<div>
			 <button type="submit" class="btn btn-dark btn-block">Update Data</button>
			</div>
			<?php 
			}
			mysqli_close($koneksi);


			?>

			 </div>
  </div>
</form>
</div>
</div>
</body>
</html>