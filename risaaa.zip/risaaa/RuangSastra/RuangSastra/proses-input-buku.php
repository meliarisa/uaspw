<?php
session_start();



//menambah data novel baru
	if(isset($_POST['addnovel'])){
     $Kode_novel= $_POST['Kode_novel'];
     $Judul_novel= $_POST['Judul_novel']; 
     $Genre= $_POST['Genre']; 
     $Harga= $_POST['Harga'];

     
     		$adddatanovel = mysqli_query($koneksi, "insert into tb_buku (Kode_novel, Judul_novel, Genre, Harga) values('$Kode_novel', '$Judul_novel', '$Genre', '$Harga')");
			if($addtotable){
				header('location:daftar-buku.php');
			} else {
				echo 'Gagal';
				header('location:daftar-buku.php');
			}
};

?>