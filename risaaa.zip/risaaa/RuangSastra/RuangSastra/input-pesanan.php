<!DOCTYPE html>
<html>
<head>
	<title>FORM INPUT PESANAN</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
  <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
body{
  background-image: url(image/walmenu2.jpg);
  background-repeat: no-repeat;
  background-size: cover;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: white;
}
.form-control{
  width: 350px;
}



    </style>
</head>
<body>

	 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
      <img src="image/ikonnav.png" alt="" width="50" height="50" class="me-2">
      <strong>Ruang SASTRA</strong>
    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="menu_utama_admin.php">Beranda</a>
          <li class="nav-item">
            <a class="nav-link" href="daftar-pesanan.php">Daftar Pesanan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">LogOut</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <form action="proses-input-pesanan.php" method="post">
	<div class="container mt-5">
		<div class="jumbotron" style="color: black;">
			<div class="card" style="color: black;">
				<h2>Input Pesanan Anda</h2>
			</div>

			<div class="card">
				<div class="card-body">
					<div class="mb-3">
					  <label for="exampleFormControlInput1" class="form-label">Kode_User</label>
					  <input type="text" name="Kode_User" class="form-control" id="exampleFormControlInput1" placeholder="Masukkan Kode User Anda">
					</div>
					<div class="mb-3">
					  <label for="exampleFormControlInput1" class="form-label">Kode_novel</label>
					  <input type="text" name="Kode_novel" class="form-control" id="exampleFormControlInput1" placeholder="Masukkan Kode Novel">
					</div>
					<div class="mb-3">
					  <label for="exampleFormControlInput1" class="form-label">Judul_novel</label>
					  <input type="text" name="Judul_novel" class="form-control" id="exampleFormControlInput1" placeholder="Masukkan Judul Novel">
					</div>
					<div class="mb-3">
					  <label for="exampleFormControlInput1" class="form-label">Harga</label>
					  <input type="text" name="Harga" class="form-control" id="exampleFormControlInput1" placeholder="Masukkan Harga Novel">
					</div>
					<div class="mb-3">
					  <label for="exampleFormControlInput1" class="form-label">Tanggal_pemesanan</label>
					  <input type="text" name="Tanggal_pemesanan" class="form-control" id="exampleFormControlInput1" placeholder="Masukkan Tanggal_pemesanan">
					</div>
					<div>
						<button type="button" class="btn btn-dark"><a href="menu_utama_user.php">KEMBALI</a></button>
						<button type="reset" class="btn btn-dark">Cancel</button>
            <button type="submit" name="proses" class="btn btn-dark">Simpan Pesanan</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>

</body>
</html>
