<!DOCTYPE html>
<html>
<head>
	<title>FORM INPUT PESANAN</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
  <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
body{
  background-image: url(image/walmenu2.jpg);
  background-repeat: no-repeat;
  background-size: cover;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: white;
}
.form-control{
  width: 350px;
}



    </style>
</head>
<body>

	 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <img src="image/ikonnav.png" alt="" width="50" height="50" class="me-2">
          <strong>Ruang SASTRA</strong>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="menu_utama_admin.php">Beranda</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="data-pegawai.php">Data Pegawai</a>
              </li>
               <li class="nav-item">
                <a class="nav-link" href="daftar-buku.php">Daftar Buku</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="daftar-pesanan-admin.php">Daftar Pesanan</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="data-pembayaran.php">Data Pembayaran</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="logout.php">LogOut</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

	<div class="container mt-5">
		<div class="jumbotron" style="color: black;">
			<div class="card" style="color: black;">
				<h2>Daftar Pesanan</h2>
			</div>

			<div class="card">
				<div class="card-body">
           <button>
           <a href="menu_utama_admin.php" class="btn btn-dark">Kembali</a>
          </button>
        </div>
					<?php  
              $ambildatanovel = mysqli_connect("localhost","root","");
              $db = mysqli_select_db($ambildatanovel, 'db_ruangsastra');

              $query = "SELECT * FROM tb_pesanan";
              $query_run = mysqli_query($ambildatanovel, $query);
            ?>

          <table class="table table-dark table-bordered">

            <thead>
              <tr>
                <th scope="col">Kode User</th>
                <th scope="col">Kode Novel</th>
                <th scope="col">Judul Novel</th>
                <th scope="col">Harga</th>
                <th scope="col">Tanggal Pemesanan</th>
                <th scope="col">Edit</th>
                <th scope="col">Hapus</th>
                <th scope="col">Proses</th>


              </tr>
            </thead>
             <?php
              if($query_run)
              {
                foreach($query_run as $row)
                {
            ?>
            <tbody>
              <tr>
                <td><?php echo $row['Kode_User']; ?></td>
                <td><?php echo $row['Kode_novel']; ?></td>
                <td><?php echo $row['Judul_novel']; ?></td>
                <td><?php echo $row['Harga']; ?></td>
                <td><?php echo $row['Tanggal_pemesanan']; ?></td>
                <td>
                  <a href="edit-pesanan.php?id=<?php echo $row['Kode_User'];?>" class="btn btn-info"><i class="fa-solid fa-pen"></i>EDIT</a>
                </td>
                <td>
                  <a href="proses-hapus-pesanan.php?id=<?php echo $row['Kode_User'];?>" class="btn btn-danger" onclick="javascript: return confirm('Anda Yakin Akan Hapus Data?')"><i class="fa-solid fa-circle-trash"></i>HAPUS</a>
                </td>
                <td>
                  <a href="input-pembayaran.php" class="btn btn-secondary"><i class="fa-solid fa-pen"></i>PROSES</a>
                </td>
                
              </tr>
            </tbody>
             <?php
                }
              }
                else
                {
                  echo "Data Tidak Ditemukan";
                }

          ?>
				</div>
			</div>
		</div>
	</div>

</body>
</html>