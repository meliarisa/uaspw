<!DOCTYPE html>
<html lang="en">
<head>
 <title>FORM EDIT NOVEL</title>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
 <script src="js/jquery.js"></script>
 <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body background="img/toge.jpg">

<?php
$id = $_GET['id'];
//koneksi database
include('koneksi.php');
//query

$result = mysqli_query($koneksi, "select*from tb_buku WHERE Kode_novel='$id'");
?>


 <h3>Update Data Novel</h3>
 <form role="form" action="proses-edit-novel.php" method="get">
<?php
 while ($row = mysqli_fetch_array($result)){?>

 <input type="hidden" name="id" value="<?php echo $row ['Kode_novel']?>">
  <div class="form-group">
  <label>Kode Novel</label>
  <input type="text" name="Kode_novel" class="form-control" value="<?php echo $row ['Kode_novel'];?>">
 </div>

 <div class="form-group">
  <label>Judul Novel</label>
  <input type="text" name="Judul_novel" class="form-control" value="<?php echo $row ['Judul_novel'];?>">
 </div>

 <div class="form-group">
  <label>Genre</label>
  <input type="text" name="Genre" class="form-control" value="<?php echo $row ['Genre'];?>">
 </div>

 <div class="form-group">
  <label>Harga</label>
  <input type="text" name="Harga" class="form-control" value="<?php echo $row ['Harga'];?>">
 </div>
 <button type="submit" class="btn btn-dark btn-block">Update Data</button>

<?php 
}
mysqli_close($koneksi);

?>
 </form>
</div>
</body>
</html>