<?php
//add dbconnect

include('koneksi.php');

$Kode_pembayaran=$_POST['Kode_pembayaran'];
$Kode_User=$_POST['Kode_User'];
$Kode_novel=$_POST['Kode_novel'];
$Judul_novel=$_POST['Judul_novel'];
$Genre=$_POST['Genre'];
$Harga=$_POST['Harga'];
$Jumlah=$_POST['Jumlah'];
$Tanggal_Pembayaran=$_POST['Tanggal_Pembayaran'];

//query

$query =  "INSERT INTO tb_pembayaran (Kode_pembayaran , Kode_User , Kode_novel , Judul_novel , Genre , Harga , Jumlah , Tanggal_Pembayaran) VALUES('$Kode_pembayaran','$Kode_User','$Kode_novel','$Judul_novel','$Genre','$Harga','$Jumlah','$Tanggal_Pembayaran')";

if(mysqli_query($koneksi , $query)) {
 # code redicet setelah insert ke index
 header("location:data-pembayaran.php");
}
else{
 echo "ERROR, tidak berhasil". mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>