<!DOCTYPE html>
<html>
<head>
	<title>MENU USER</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/brands.min.css" charset="utf-8"></script>
	<style>
		*{
	margin: 0;
	padding: 0;
	list-style: none;
	text-decoration: none;
	box-sizing: border-box;
	font-family: "Roboto", sans-serif;
}

body{
	background: white;
}

.wrapper .header{
	z-index: 1;
	background: #22242A;
	position: fixed;
	width: calc(100% - 0%);
	height: 70px;
	display: flex;
	top: 0;
}

.wrapper .header .header-menu{
	width: calc(100% - 0%);
	height: 100%;
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 0 20px;
}

.wrapper .header .header-menu .title{
	color: white;
	font-size: 25px;
	text-transform: uppercase;
	font-weight: 900;

}

.wrapper .header .header-menu .title span{
	color: #4CCEE8;
}

.wrapper .header .header-menu .sidebar-btn{
	color: white;
	position: absolute;
	margin-left: 240px;
	font-size: 22px;
	font-weight: 900;
	cursor: pointer;
	transition: 0.3s;
	transition-property: color;
}

.wrapper .header .header-menu .sidebar-btn:hover{
	color: #4CCEE8;
}

.wrapper .header .header-menu ul{
	display: flex;
}

.wrapper .header .header-menu ul li a{
	background: white;
	color: #000;
	display: block;
	margin: 0 10px;
	font-size: 18px;
	width: 34px;
	line-height: 35px;
	text-align: center;
	border-radius: 50%;
	transition: 0.3s;
	transition-property: background, color;
}

.wrapper .header .header-menu ul li a:hover{
	background:  #4CCEE8;
	color: white;
}

.wrapper .sidebar{
	z-index: 1;
	background: #2F323A;
	position: fixed;
	top: 70px;
	width: 250px;
	height: calc(100% - 9%);
	transition: 0.3s;
	transition-property: width;
	overflow-y: auto;
}

.wrapper .sidebar .sidebar-menu{
	overflow: hidden;
}

.wrapper .sidebar .sidebar-menu .profile img{
	margin: 20px 0;
	width: 100px;
	height: 100px;
	border-radius: 50%;
}

.wrapper .sidebar .sidebar-menu .profile p{
	color: white;
	font-weight: 700;
	margin-bottom: 10px;
}

.wrapper .sidebar .sidebar-menu .item{
	width: 250px;
	overflow: hidden;
}

.wrapper .sidebar .sidebar-menu .item .menu-btn{
	display: block;
	color: white;
	position: relative;
	padding: 25px 20px;
	transition: 0.3s;
	transition-property: color;

}

.wrapper .sidebar .sidebar-menu .item .menu-btn:hover{
	color: #4CCEE8;
}

.wrapper .sidebar .sidebar-menu .item .menu-btn i{
	margin-right: 20px;
}

.wrapper .sidebar .sidebar-menu .item .menu-btn .drop-down{
	float: right;
	font-size: 12px;
	margin-top: 3px;
}

.wrapper .sidebar .sidebar-menu .item .sub-menu{
	background: #3439DB;
	overflow-wrap: hidden;
	max-height: 0;
	transition: 0.3s;
	transition-property: background, max-height;
}

.wrapper .sidebar .sidebar-menu .item .sub-menu a{
	display: block;
	position: relative;
	color: white;
	white-space: nowrap;
	font-size: 15px;
	padding: 20px;
	border-bottom: 1px solid #8FC5E9;
	transition: 0.3s;
	transition-property: background;
}

.wrapper .sidebar .sidebar-menu .item .sub-menu a:hover{
	background: #55B1F0;
}

.wrapper .sidebar .sidebar-menu .item .sub-menu i{
	padding-right: 20px;
	font-size: 10px;
}

.wrapper .sidebar .sidebar-menu .item:target .sub-menu{
	max-height: 500px;
}

.wrapper .main-container{
	width: (100% - 250px);
	margin-top: 70px;
	margin-left: 250px;
	padding: 15px;
	background: url(image/walmenu2.jpg) no-repeat;
	background-size: cover;
	height: 100vh;
	transition: 0.3s;
}

.wrapper .collapse .sidebar{
	width: 70px;
}

.wrapper.collapse .sidebar .profile img, 
.wrapper.collapse .sidebar .profile p,
.wrapper.collapse .sidebar a span{
	display: none;
}

.wrapper.collapse .sidebar .sidebar-menu .item .menu-btn{
	font-size: 23px;
}

.wrapper.collapse .sidebar .sidebar-menu .item .sub-menu i{
	font-size: 18px;
	padding-right: 3px;
}

.wrapper.collapse .main-container{
	width: (100% - 70px);
	margin-left: 70px;
}

.wrapper .main-container .card{
	background: white;
	padding: 15px;
	font-size: 14px;
	margin-bottom: 10px;
}


	</style>
</head>
<body>
	<!--wrapper start -->
	<div class="wrapper">
		<!--header menu start-->
		<div class="header">
			<div class="header-menu">
				<div class="tittle"><b>RUANG<span>SASTRA</span></b></div>
				<div class="sidebar-btn">
					<i class="fa-solid fa-bars"></i>
				</div>
				<ul>
					<li><a href="seacrh.php"><i class="fa-solid fa-search"></i></li>
					<li><a href="logout.php"><i class="fa-solid fa-sign-out"></i></li>
				</ul>
			</div>
		</div>
		<!--header menu end-->
		<!--sidebar start-->
		<div class="sidebar">
			<div class="sidebar-menu">
				<center class="profile">
					<img src="image/ikon.png" alt="">
					<p>Ari Trisna</p>
				</center>
				<li class="item">
				<a href="menu-user.php" class="menu-btn">
					<i class="fa-solid fa-house-user"></i><span>HOME</span>
				</a>
				</li>
				<li class="item" id="profile">
				<a href="#profile" class="menu-btn">
				<i class="fa-solid fa-books"></i><span>Daftar Novel  <i class="fas fa-chevron-down drop-down"></i></span>
			</a>
			<div class="sub-menu">
				<a href="comedi.php"><i class="fa-duotone fa-face-grin-tears"></i><span>Comedi</span></a>
				<a href="horor.php"><i class="fa-duotone fa-face-grin-tears"></i><span>Horor</span></a>
				<a href="romance.php"><i class="fa-duotone fa-face-grin-tears"></i><span>Romance</span></a>
				<a href="fantasy.php"><i class="fa-duotone fa-face-grin-tears"></i><span>Fantasy</span></a>
			</div>
		</li>
			<li class="item">
				<a href="daftar-pesanan.php" class="menu-btn">
					<i class="fa-duotone fa-bags-shopping"></i><span>Daftar Pesanan</span>
				</a>
				</li>
			<li>
				<li class="item">
					<a href="logout.php" class="menu-btn">
						<i class="fa-solid fa-sign-out"></i><span>LogOut</span>
				</li>
			</div>
		</div>
		<!--sidebar end-->
		<!--main container start-->
		<div class="main-container">
			<div class="card">
				<p>SELAMAT DATANG DI RUANG SASTRA</p>
			</div>
		</div>
		<!--main container end-->

	</div>
	<!--wrapper end -->
	<script type="text/javascript">
		(document).ready(function(){
			$(".sidebar-btn").click(function(){
				$(".wrapper").toggleClass("collapse");
			});
		});
	</script>
	

</body>
</html>