<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.min">
    <link rel="stylesheet" type="text/css" href="fontawesome-free/css/style.css">

    <title>MENU USER</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
body{
  background-color: #C0C0C0;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: #2D2D2D;
}
.form-control{
  width: 350px;
}

.img-genre{
  width: 50px;
}

.img-genre{
  width: 50px;
}

.img-genre:hover{
  transform: scale(1.2);
}

.row-container{
  background-color: white;
  margin: 0px;
}


    </style>
  </head>
  <body>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
      <img src="image/ikonnav.png" alt="" width="50" height="50" class="me-2">
      <strong>Ruang SASTRA</strong>
    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="menu_utama_user.php">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="daftar-pesanan.php">Daftar Pesanan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">LogOut</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
      <div class="container">
      <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <center><div class="carousel-item active">
          <img src="image/mariposa.webp" class="d-block" alt="...">
        </div>
        <div class="carousel-item">
          <img src="image/mozaciko.jpg" class="d-block" alt="...">
        </div>
        <div class="carousel-item">
          <img src="image/gal.jpg" class="d-block" alt="...">
        </div>
        <div class="carousel-item">
          <img src="image/anta.jpg" class="d-block" alt="...">
        </div>
        <div class="carousel-item">
          <img src="image/asep.jpg" class="d-block" alt="...">
        </div>
      </div></center>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
    </div>

    <!-- Genre -->
    <div class="container mt-5">
      <div class="judul-genre" style="background-color: white; padding: 5px 10px;">
        <h5 class="text-center" style="margin-top: 5px;">GENRE NOVEL</h5>
      </div>
      <div class="row text-center row-container mt-2">
        <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="humor.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>HUMOR</strong></p>
          </div>
        </div>

         <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="horor.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>HOROR</strong></p>
          </div>
        </div>

         <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="fantasy.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>FANTASY</strong></p>
          </div>
        </div>

         <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="romance.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>ROMANCE</strong></p>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="misteri.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>MISTERI</strong></p>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="vampir.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>VAMPIR</strong></p>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="puisi.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>PUISI</strong></p>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-4 col-4">
          <div class="Genre">
            <a href="petualangan.php"><img src="image/ikongen.png" class="img-genre mt-3"></a>
            <p class="mt-4"><strong>PETUALANGAN</strong></p>
          </div>
        </div>
      </div>
    </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>