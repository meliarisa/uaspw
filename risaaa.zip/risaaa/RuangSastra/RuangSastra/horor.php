<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>HOROR</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
body{
  background-color: #C0C0C0;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: #2D2D2D;
}
.form-control{
  width: 350px;
}

</style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
      <img src="image/ikonnav.png" alt="" width="50" height="50" class="me-2">
      <strong>Ruang SASTRA</strong>
    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="menu_utama_user.php">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="daftar-pesanan.php">Daftar Pesanan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">LogOut</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
    <!-- HUMOR start -->
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/h1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">DANGEROUS GHOST</h6>
            <p class="card-text">Kode Novel : N0017</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/h2.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">RUMAH DUKUN</h6>
            <p class="card-text">Kode Novel : N0018</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/h3.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Gulai Daging Ibu</h6>
            <p class="card-text">Kode Novel : N0019</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/h4.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">RUMAH SEBERANG JALAN</h6>
            <p class="card-text">Kode Novel : N0020</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h5.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Selamat Dari Tumbal Pesugihan</h6>
            <p class="card-text">Kode Novel : N0021</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h6.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Kidung Kemoja</h6>
            <p class="card-text">Kode Novel : N0022</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h7.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">SUSUK TERATAI PUTIH </h6>
            <p class="card-text">Kode Novel : N0023</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h8.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Bau Busuk Kamar Sebelah</h6>
            <p class="card-text">Kode Novel : N0024</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h9.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">BINTARI</h6>
            <p class="card-text">Kode Novel : N0025</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-4 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h10.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">PITUNG DINO </h6>
            <p class="card-text">Kode Novel : N0026</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h11.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">KERANDA POCONG PART</h6>
            <p class="card-text">Kode Novel : N0027</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h12.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Ratu Kuntilanak</h6>
            <p class="card-text">Kode Novel : N0028</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h13.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">SUAMIKU GENDERUWO</h6>
            <p class="card-text">Kode Novel : N0029</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h14.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Dendam Sang Iblis </h6>
            <p class="card-text">Kode Novel : N0030</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h15.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Mayat Dalam Sumur</h6>
            <p class="card-text">Kode Novel : N0031</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/h16.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">KOTA MATI</h6>
            <p class="card-text">Kode Novel : N0032</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>
      </div>
    </div>
    <!-- HUMOR end -->
    <div class="text-center mt-4">
     <a href="menu_utama_user.php" class="btn btn-dark d-grid">Kembali</a>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>