<!DOCTYPE html>
<html>
<head>
	<title>FORM CETAK</title>
</head>
<body>
	<?php
	include "koneksi.php";
	?>
	<table border="2" style="width:100%">
		<tr>
			<th>Kode Pembayaran</th>
			<th>Kode User</th>
			<th>Kode Novel</th>
			<th>Judul Novel</th>
			<th>Genre</th>
			<th>Harga</th>
			<th>Jumlah</th>
			<th>Tanggal Pembayaran</th>
		</tr>
		<?php
		$sql=mysqli_query($koneksi, "select*from tb_pembayaran");
		while($hasil=mysqli_fetch_array($sql)){
			?>
			<tr>
				<td><?php echo $hasil['Kode_pembayaran'];?></td>
				<td><?php echo $hasil['Kode_User'];?></td>
				<td><?php echo $hasil['Kode_novel'];?></td>
				<td><?php echo $hasil['Judul_novel'];?></td>
				<td><?php echo $hasil['Genre'];?></td>
				<td><?php echo $hasil['Harga'];?></td>
				<td><?php echo $hasil['Jumlah'];?></td>
				<td><?php echo $hasil['Tanggal_Pembayaran'];?></td>
			</tr>
			<?php
		}
		?>
	</table>
	<br>
	<br>
	<br>
	<script>
		window.print()
	</script>
</body>
</html>