<?php
//add dbconnect

include('koneksi.php');

$Kode_User=$_POST['Kode_User'];
$Nama=$_POST['Nama'];
$Umur=$_POST['Umur'];
$Alamat=$_POST['Alamat'];
$No_Telepon=$_POST['No_Telepon'];
$Username=$_POST['Username'];
$Password=$_POST['Password'];


//query

$query =  "INSERT INTO tb_user (Kode_User , Nama , Umur , Alamat , No_Telepon, Username, Password) VALUES('$Kode_User','$Nama','$Umur','$Alamat','$No_Telepon', '$Username', '$Password')";

if(mysqli_query($koneksi , $query)) {
 # code redicet setelah insert ke index
 header("location:input-user.php");
}
else{
 echo "ERROR, tidak berhasil". mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>