<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id'];
$Kode_novel= $_GET['Kode_novel'];
$Judul_novel = $_GET['Judul_novel'];
$Genre= $_GET['Genre'];
$Harga= $_GET['Harga'];

//query update
$query = "UPDATE tb_buku SET Kode_novel='$Kode_novel', Judul_novel='$Judul_novel' ,
 Genre='$Genre', Harga='$Harga'  WHERE Kode_novel='$id'";

if (mysqli_query($koneksi, $query)) {
 # credirect ke page index
 header("location:daftar-buku.php");
 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>