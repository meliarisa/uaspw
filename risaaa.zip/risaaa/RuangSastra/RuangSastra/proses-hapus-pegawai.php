<?php
include ("koneksi.php");
$id=$_GET['id'];

$query="DELETE from tb_admin WHERE Kode_pegawai='$id'";
$hasil=mysqli_query($koneksi, $query);

if($hasil){
header('location:data-pegawai.php');

}else{
	echo "Hapus data gagal!";
}

?>