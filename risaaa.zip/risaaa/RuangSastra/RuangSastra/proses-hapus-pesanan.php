<?php
include ("koneksi.php");
$id=$_GET['id'];

$query="DELETE from tb_pesanan WHERE Kode_User='$id'";
$hasil=mysqli_query($koneksi, $query);

if($hasil){
header('location:daftar-pesanan-admin.php');

}else{
	echo "Hapus data gagal!";
}

?>