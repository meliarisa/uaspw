<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>PETUALANGAN</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
body{
  background-color: #C0C0C0;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: #2D2D2D;
}
.form-control{
  width: 350px;
}

</style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
      <img src="image/ikonnav.png" alt="" width="50" height="50" class="me-2">
      <strong>Ruang SASTRA</strong>
    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <form class="d-flex ms-auto">
      <input class="form-control me-2" type="search" placeholder="Cari Novel Anda" aria-label="Cari">
      <button class="btn btn-light" type="submit">Cari</button>
    </form>
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="menu_utama_user.php">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="daftar-pesanan.php">Daftar Pesanan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">LogOut</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
    <!-- HUMOR start -->
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/t1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">𝐓𝐡𝐞 𝐕𝐢𝐥𝐥𝐚𝐢𝐧𝐞𝐬𝐬</h6>
            <p class="card-text">Kode Novel : N0113</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/t2.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Naughty Zee</h6>
            <p class="card-text">Kode Novel : N0114</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/t3.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Mengubah Takdir Antagonis</h6>
            <p class="card-text">Kode Novel : N0115</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6">
        <div class="card text-center">
          <img src="image/t4.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Unwritten Figure</h6>
            <p class="card-text">Kode Novel : N0116</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t5.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">I'm Fine</h6>
            <p class="card-text">Kode Novel : N0117</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t6.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">its me</h6>
            <p class="card-text">Kode Novel : N0118</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t7.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Penjaga Hati</h6>
            <p class="card-text">50.000</p>
            <p class="card-text">Kode Novel : N0119</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t8.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">JADI FIGURAN TERUS</h6>
            <p class="card-text">Kode Novel : N0120</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t9.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">TEMPUS ITINERANTUR</h6>
            <p class="card-text">Kode Novel : N0121</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-4 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t10.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Kingsley & Queenza</h6>
            <p class="card-text">Kode Novel : N0122</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t11.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">DESTINY </h6>
            <p class="card-text">Kode Novel : N0123</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t12.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Talented Girl</h6>
            <p class="card-text">Kode Novel : N0124</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t13.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">The Liu Empire</h6>
            <p class="card-text">Kode Novel : N0125</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t14.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Honeymoon Travels</h6>
            <p class="card-text">Kode Novel : N0126</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t15.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">Secret Character ✔️</h6>
            <p class="card-text">Kode Novel : N0127</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>

         <div class="col-lg-3 col-md-2 col-sm-4 col-6 mt-2">
        <div class="card text-center">
          <img src="image/t16.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h6 class="card-title">the last night</h6>
            <p class="card-text">Kode Novel : N0128</p>
            <p class="card-text">50.000</p>
            <a href="input-pesanan.php" class="btn btn-dark d-grid">Beli</a>
          </div>
        </div>
        </div>
      </div>
    </div>
    <!-- HUMOR end -->
    <div class="text-center mt-4">
     <a href="menu_utama_user.php" class="btn btn-dark d-grid">Kembali</a>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>