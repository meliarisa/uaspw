<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id'];
$Kode_pegawai = $_GET['Kode_pegawai'];
$Nama_pegawai = $_GET['Nama_pegawai'];
$Umur = $_GET['Umur'];
$Alamat = $_GET['Alamat'];
$Jenis_Kelamin = $_GET['Jenis_Kelamin'];
$No_telepon = $_GET['No_telepon'];
$Username = $_GET['Username'];
$Password = $_GET['Password'];

//query update
$query = "UPDATE tb_admin SET Kode_pegawai='$Kode_pegawai', Nama_pegawai='$Nama_pegawai' , Umur='$Umur', Alamat='$Alamat', Jenis_Kelamin='$Jenis_Kelamin', No_telepon='$No_telepon', Username='$Username', Password='$Password' WHERE Kode_pegawai='$id'";

if (mysqli_query($koneksi, $query)) {
 # credirect ke page index
 header("location:data-pegawai.php");
 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>