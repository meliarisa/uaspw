<?php
session_start();
include 'koneksi.php';

$Username = $_POST['Username'];
$Password = $_POST['Password'];

$login = mysqli_query($koneksi,"select* from tb_admin where Username='$Username' and Password='$Password'");
$ketemu = mysqli_num_rows($login);

if($ketemu > 0){
	#jika ketemu
	$_SESSION['Username'] = $Username;
	$_SESSION['Password'] = $Password;
	header("location:menu_utama_admin.php");
}else{
	header("location:login2.php?pesan=gagal");
}

?>
