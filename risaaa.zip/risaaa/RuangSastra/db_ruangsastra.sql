-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2022 at 03:14 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ruangsastra`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `Kode_pegawai` varchar(100) NOT NULL,
  `Nama_pegawai` varchar(100) NOT NULL,
  `Umur` varchar(100) NOT NULL,
  `Alamat` text NOT NULL,
  `Jenis_Kelamin` varchar(100) NOT NULL,
  `No_telepon` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`Kode_pegawai`, `Nama_pegawai`, `Umur`, `Alamat`, `Jenis_Kelamin`, `No_telepon`, `Username`, `Password`) VALUES
('A0003', 'yanto', '19 Tahun', 'Bogor', 'Pria', '081674972848', 'yantooo', 'punyajenab');

-- --------------------------------------------------------

--
-- Table structure for table `tb_buku`
--

CREATE TABLE `tb_buku` (
  `Kode_novel` varchar(100) NOT NULL,
  `Judul_novel` varchar(100) NOT NULL,
  `Genre` varchar(100) NOT NULL,
  `Harga` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_buku`
--

INSERT INTO `tb_buku` (`Kode_novel`, `Judul_novel`, `Genre`, `Harga`) VALUES
('N0001', 'ANTAGONIS WORLD\'S', 'HUMOR', '70.000'),
('N0002', 'Bawang Merah Putih', 'HUMOR', '75.000'),
('N0003', 'JODOHKU ANAK SANTRI', 'HUMOR', '70.000'),
('N0004', 'I DON\'T CARE', 'HUMOR', '70.000'),
('N0005', 'Mr. Clean\r\n', 'HUMOR', '70.000'),
('N0006', 'ANAK PIYIK🐥', 'HUMOR', '70.000'),
('N0007', 'Tiga', 'HUMOR', '70.000'),
('N0008', 'Sweet Family ✅', 'HUMOR', '70.000'),
('N0009', 'Penggombal Ulung', 'HUMOR', '70.000'),
('N0010', 'Family Gaje II - After Baby', 'HUMOR', '70.000'),
('N0011', 'SAVLORA | Sosiologi Cinta', 'HUMOR', '70.000'),
('N0012', 'KeVia: My Enemy My Love', 'HUMOR', '70.000'),
('N0013', 'BULBUL!', 'HUMOR', '70.000'),
('N0014', 'Rora Is Not Quin', 'HUMOR', '70.000'),
('N0015', 'POTRET CINTA', 'HUMOR', '70.000'),
('N0016', 'Jungkir Balik Semesta Rinai', 'HUMOR', '70.000'),
('N0017', 'DANGEROUS GHOST', 'HOROR', '50.000'),
('N0018', 'RUMAH DUKUN', 'HOROR', '50.000'),
('N0019', 'Gulai Daging Ibu', 'HOROR', '50.000'),
('N0020', 'RUMAH SEBERANG JALAN', 'HOROR', '50.000'),
('N0021', 'Selamat Dari Tumbal Pesugihan', 'HOROR', '50.000'),
('N0022', 'Kidung Kemoja', 'HOROR', '50.000'),
('N0023', 'SUSUK TERATAI PUTIH', 'HOROR', '50.000'),
('N0024', 'Bau Busuk Kamar Sebelah', 'HOROR', '50.000'),
('N0025', 'BINTARI', 'HOROR', '50.000'),
('N0026', 'PITUNG DINO', 'HOROR', '50.000'),
('N0027', 'KERANDA POCONG PART', 'HOROR', '50.000'),
('N0028', 'Ratu Kuntilanak', 'HOROR', '50.000'),
('N0029', 'SUAMIKU GENDERUWO', 'HOROR', '50.000'),
('N0030', 'Dendam Sang Iblis', 'HOROR', '50.000'),
('N0031', 'Mayat Dalam Sumur', 'HOROR', '50.000'),
('N0032', 'KOTA MATI', 'HOROR', '50.000'),
('N0033', 'Am I Antagonist?', 'FANTASY', '50.000'),
('N0034', 'Transmigrasi Queen Amoora', 'FANTASY', '50.000'),
('N0035', 'It\'s My Destiny', 'FANTASY', '50.000'),
('N0036', 'Daisy and Millitary Commander', 'FANTASY', '50.000'),
('N0037', 'The Unstella : Antagonist Talent', 'FANTASY', '50.000'),
('N0038', 'FATE:Rebirth of the princess', 'FANTASY', '50.000'),
('N0039', 'My World', 'FANTASY', '50.000'),
('N0040', 'Obsesi Antagonis', 'FANTASY', '50.000'),
('N0041', 'Miss Adelaine\'s Revenge', 'FANTASY', '50.000'),
('N0042', 'Sweet Figuran', 'FANTASY', '50.000'),
('N0043', 'Mengulang Waktu', 'FANTASY', '50.000'),
('N0044', 'THE ABSURD WIFE', 'FANTASY', '50.000'),
('N0045', 'Transmigrasi Staff Idol', 'FANTASY', '50.000'),
('N0046', 'I Refuse to Die', 'FANTASY', '50.000'),
('N0047', 'Transfert D\'âme', 'FANTASY', '50.000'),
('N0048', 'Orenda', 'FANTASY', '50.000'),
('N0049', 'NATHAN', 'ROMANCE', '50.000'),
('N0050', 'Hei, Araya!', 'ROMANCE', '50.000'),
('N0051', 'Dia Naina', 'ROMANCE', '50.000'),
('N0052', 'One More Chance', 'ROMANCE', '50.000'),
('N0053', 'LOVE YOU MY ICE', 'ROMANCE', '50.000'),
('N0054', 'ALLEA', 'ROMANCE', '50.000'),
('N0055', 'POSSESSIVE ARSENAL', 'ROMANCE', '50.000'),
('N0056', 'MENCURI PERAN', 'ROMANCE', '50.000'),
('N0057', 'Nikahmuda✔', 'ROMANCE', '50.000'),
('N0058', 'AGATHA', 'ROMANCE', '50.000'),
('N0059', 'F U T U R E M O M M Y', 'ROMANCE', '50.000'),
('N0060', 'Possessive Badboy', 'ROMANCE', '50.000'),
('N0061', 'Trapped Married', 'ROMANCE', '50.000'),
('N0062', 'Leader Girl', 'ROMANCE', '50.000'),
('N0063', 'Mesin Waktu\r\n', 'ROMANCE', '50.000'),
('N0064', 'NARAKASA', 'ROMANCE', '50.000'),
('N0065', 'THE CLASS', 'MISTERI', '50.000'),
('N0066', 'Can\'t Escape', 'MISTERI', '50.000'),
('N0067', 'Seamless ✓', 'MISTERI', '50.000'),
('N0068', 'CYRAKHA', 'MISTERI', '50.000'),
('N0069', 'My Psychopath Patient', 'MISTERI', '50.000'),
('N0070', 'Menuntut Balas (✔)', 'MISTERI', '50.000'),
('N0071', 'Crazy Psycho', 'MISTERI', '50.000'),
('N0072', 'OLIVER\'S PUZZLE', 'MISTERI', '50.000'),
('N0073', 'HEI, BODYGUARD!', 'MISTERI', '50.000'),
('N0074', 'Dont Believe\r\n', 'MISTERI', '50.000'),
('N0075', 'My Psycho Boyfriend', 'MISTERI', '50.000'),
('N0076', 'DEATH SCHOOL', 'MISTERI', '50.000'),
('N0077', 'jam 12 malam', 'MISTERI', '50.000'),
('N0078', 'Immortal King', 'MISTERI', '50.000'),
('N0079', 'Tragedi Toilet Sekolah', 'MISTERI', '50.000'),
('N0080', 'RUMAH TANAH TUA', 'MISTERI', '50.000'),
('N0081', 'The Queen', 'VAMPIR', '50.000'),
('N0082', 'Queen And The Dark\r\n', 'VAMPIR', '50.000'),
('N0083', 'The Unwanted Queen', 'VAMPIR', '50.000'),
('N0084', 'Little Baby Vs Big Baby Vampir', 'VAMPIR', '50.000'),
('N0085', 'Rebirth \"Orphic : All i needed\"', 'VAMPIR', '50.000'),
('N0086', 'The NECROMANCER', 'VAMPIR', '50.000'),
('N0087', 'Grąmoral Matę', 'VAMPIR', '50.000'),
('N0088', 'TERPILIH', 'VAMPIR', '50.000'),
('N0089', 'My Queen', 'VAMPIR', '50.000'),
('N0090', 'Lady of Daimon ✓', 'VAMPIR', '50.000'),
('N0091', 'King\'s Obsession', 'VAMPIR', '50.000'),
('N0092', 'NATHAN\r\n', 'VAMPIR', '50.000'),
('N0093', 'NECROMANCER', 'VAMPIR', '50.000'),
('N0094', '7 PRINCE', 'VAMPIR', '50.000'),
('N0095', 'Possessive Kahfi', 'VAMPIR', '50.000'),
('N0096', '𝙰𝙱𝙾𝚄𝚃 𝙳𝙴𝚂𝚃𝙸𝙽𝚈 | 𝚀𝚄𝙴𝙴𝙽𝚉𝚈', 'VAMPIR', '50.000'),
('N0097', 'Ruang Diksi', 'PUISI', '50.000'),
('N0098', 'Puisiku', 'PUISI', '50.000'),
('N0099', 'Quotes', 'PUISI', '50.000'),
('N0100', 'Fiersa Besari', 'PUISI', '50.000'),
('N0101', 'Filosofi Semesta', 'PUISI', '50.000'),
('N0102', 'Diam', 'PUISI', ''),
('N0103', 'Madah Qolbu❣️', 'PUISI', '50.000'),
('N0104', 'Untuk Kertas & Pena', 'PUISI', '50.000'),
('N0105', 'How I Feel', 'PUISI', '50.000'),
('N0106', 'Sekumpulan Sesak', 'PUISI', '50.000'),
('N0107', 'Untaian Kata', 'PUISI', '50.000'),
('N0108', 'Yang Tidak Tersampaikan ✔', 'PUISI', '50.000'),
('N0109', 'Dialog Mahasunyi', 'PUISI', '50.000'),
('N0110', 'Pojok Aksara', 'PUISI', '50.000'),
('N0111', 'My Short Quotes.', 'PUISI', '50.000'),
('N0112', 'Aku Pengamat, Terasingkan', 'PUISI', '50.000'),
('N0113', '𝐓𝐡𝐞 𝐕𝐢𝐥𝐥𝐚𝐢𝐧𝐞𝐬𝐬', 'PETUALANGAN', '50.000'),
('N0114', 'Naughty Zee', 'PETUALANGAN', '50.000'),
('N0115', 'Mengubah Takdir Antagonis', 'PETUALANGAN', '50.000'),
('N0116', 'Unwritten Figure', 'PETUALANGAN', '50.000'),
('N0117', 'I\'m Fine', 'PETUALANGAN', '50.000'),
('N0118', 'its me\r\n', 'PETUALANGAN', '50.000'),
('N0119', 'Penjaga Hati', 'PETUALANGAN', '50.000'),
('N0120', 'JADI FIGURAN TERUS', 'PETUALANGAN', '50.000'),
('N0121', 'TEMPUS ITINERANTUR', 'PETUALANGAN', '50.000'),
('N0122', 'Kingsley & Queenza', 'PETUALANGAN', '50.000'),
('N0123', 'DESTINY', 'PETUALANGAN', '50.000'),
('N0124', 'Talented Girl', 'PETUALANGAN', '50.000'),
('N0125', 'The Liu Empire', 'PETUALANGAN', '50.000'),
('N0126', 'Honeymoon Travels', 'PETUALANGAN', '50.000'),
('N0127', 'Secret Character ✔️', 'PETUALANGAN', '50.000'),
('N0128', 'the last night', 'PETUALANGAN', '50.000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembayaran`
--

CREATE TABLE `tb_pembayaran` (
  `Kode_pembayaran` varchar(11) NOT NULL,
  `Kode_User` varchar(100) NOT NULL,
  `Kode_novel` varchar(100) NOT NULL,
  `Judul_novel` varchar(100) NOT NULL,
  `Genre` varchar(100) NOT NULL,
  `Harga` varchar(100) NOT NULL,
  `Jumlah` int(100) NOT NULL,
  `Tanggal_Pembayaran` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pembayaran`
--

INSERT INTO `tb_pembayaran` (`Kode_pembayaran`, `Kode_User`, `Kode_novel`, `Judul_novel`, `Genre`, `Harga`, `Jumlah`, `Tanggal_Pembayaran`) VALUES
('P0001', 'U001', 'N0001', 'ANTAGONIS WORLDS', 'Humor', '70.000', 3, '14 Januari 2022');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesanan`
--

CREATE TABLE `tb_pesanan` (
  `Kode_User` varchar(100) NOT NULL,
  `Kode_novel` varchar(100) NOT NULL,
  `Judul_novel` varchar(100) NOT NULL,
  `Harga` varchar(100) NOT NULL,
  `Tanggal_pemesanan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pesanan`
--

INSERT INTO `tb_pesanan` (`Kode_User`, `Kode_novel`, `Judul_novel`, `Harga`, `Tanggal_pemesanan`) VALUES
('U001', 'N0001', 'ANTAGONIS WORLDS', '70.000', '05 juni 2004');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `Kode_User` varchar(100) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `Umur` varchar(100) NOT NULL,
  `Alamat` varchar(100) NOT NULL,
  `No_Telepon` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`Kode_User`, `Nama`, `Umur`, `Alamat`, `No_Telepon`, `Username`, `Password`) VALUES
('U0001', 'Jenab', '18 Tahun', 'Baluk 2', '081999664604', 'Jenabbb', 'punyayanto'),
('U002', 'Koncreng', '19 Tahun', 'BALUK', '081674972848', 'NURULBJ', 'SURTI01'),
('U003', 'Ari', '19 Tahun', 'baluk', '', 'NJEPP', 'DEKWIRAN04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`Kode_pegawai`);

--
-- Indexes for table `tb_buku`
--
ALTER TABLE `tb_buku`
  ADD PRIMARY KEY (`Kode_novel`);

--
-- Indexes for table `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  ADD PRIMARY KEY (`Kode_pembayaran`),
  ADD UNIQUE KEY `Kode_novel` (`Kode_novel`),
  ADD UNIQUE KEY `Kode_User` (`Kode_User`);

--
-- Indexes for table `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  ADD PRIMARY KEY (`Kode_User`),
  ADD UNIQUE KEY `Kode_novel` (`Kode_novel`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`Kode_User`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  ADD CONSTRAINT `tb_pembayaran_ibfk_3` FOREIGN KEY (`Kode_novel`) REFERENCES `tb_buku` (`Kode_novel`),
  ADD CONSTRAINT `tb_pembayaran_ibfk_4` FOREIGN KEY (`Kode_User`) REFERENCES `tb_pesanan` (`Kode_User`);

--
-- Constraints for table `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  ADD CONSTRAINT `tb_pesanan_ibfk_1` FOREIGN KEY (`Kode_novel`) REFERENCES `tb_buku` (`Kode_novel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
